*PADS-LIBRARY-SCH-DECALS-V9*

HC49SDLF-24.0MHz          32000 32000 100 10 100 10 4 5 0 2 24
TIMESTAMP 2022.06.08.07.54.33
"Default Font"
"Default Font"
350   250   0 24 100 10 "Default Font"
REF-DES
350   150   0 24 100 10 "Default Font"
PART-TYPE
200   -200  0 28 100 10 "Default Font"
*
200   -300  0 28 100 10 "Default Font"
*
OPEN   2 10 0 -1
120   100  
120   -100 
OPEN   2 10 0 -1
280   100  
280   -100 
CLOSED 5 10 0 -1
160   140  
160   -140 
240   -140 
240   140  
160   140  
OPEN   2 10 0 -1
280   0    
300   0    
OPEN   2 10 0 -1
120   0    
100   0    
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T400   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*